import React from 'react';
import { Instruction } from '../types';
import InstructionItem from './InstructionItem';

type Props = {
  instructions: Instruction[];
  setInstructions: React.Dispatch<React.SetStateAction<Instruction[]>>;
  onHighlight?: (id: string) => void;
};

const InstructionList: React.FC<Props> = ({ instructions, setInstructions, onHighlight }) => {
  return (
    <aside className="space-y-4">
      <h2 className="text-lg font-semibold mb-2">
        修正指示（{instructions.length}件）
      </h2>
      <ul className="space-y-2">
      {Array.isArray(instructions) &&
        instructions.map((ins, index) => (
          <li key={ins.id}>
            <div
              className="p-2 rounded hover:bg-gray-100 border-gray-300 cursor-pointer"
              onClick={() => onHighlight?.(ins.id)}
            >
              <InstructionItem
                instruction={ins}
                setInstructions={setInstructions}
                index={index}
              />
            </div>
          </li>
        ))}
      </ul>
    </aside>
  );
};

export default InstructionList;
