import React, { useState, useEffect } from 'react';
import { Instruction } from '../types';

type Props = {
  instruction: Instruction;
  setInstructions: React.Dispatch<React.SetStateAction<Instruction[]>>;
  index: number;
};

const InstructionItem: React.FC<Props> = ({ instruction, setInstructions, index }) => {
  const [editMode, setEditMode] = useState(false);
  const [text, setText] = useState(instruction.text);

  useEffect(() => {
    if (instruction.text === '') {
      setEditMode(true);
    }
  }, [instruction.text]);

  const handleSaveEdit = () => {
    setInstructions(prev => {
      console.log('🔍 更新前の instructions:', prev); // ← これで確認できる
      return prev.map(ins =>
        ins.id === instruction.id ? { ...ins, text } : ins
      );
    });
    setEditMode(false);
  };

  const handleDelete = () => {
    if (window.confirm('この指示を削除してもよろしいですか？')) {
      setInstructions(prev => prev.filter(ins => ins.id !== instruction.id));
    }
  };

  return (
    <div className="mb-4 p-3 rounded shadow-sm bg-white">
      <div className="text-sm text-gray-500 mb-1">
        指示 {index + 1}
      </div>

      {editMode ? (
        <div>
          <textarea
            value={text}
            onChange={e => setText(e.target.value)}
            rows={3}
            className="w-full p-2rounded text-sm"
          />
          <div className="flex justify-end items-end">
            <button
              onClick={handleSaveEdit}
              className="ml-2 text-red-600 hover:text-red-800 text-sm"
            >
            保存
            </button>
            <button
              onClick={handleDelete}
              className="ml-2 text-red-600 hover:text-red-800 text-sm"
            >
            🗑
            </button>
          </div>
        </div>
      ) : (
        <div className="flex justify-between items-start">
          <p className="text-sm whitespace-pre-wrap">{instruction.text || <em>（未入力）</em>}</p>
          <div className="flex justify-end items-end">
            <button
              onClick={handleDelete}
              className="ml-2 text-red-600 hover:text-red-800 text-sm"
            >
            🗑
            </button>
          </div>
        </div>
      )}
    </div>
  );
};

export default InstructionItem;
