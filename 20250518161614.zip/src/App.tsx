import React, { useState } from 'react';
import ImageUploader from './components/ImageUploader';
import CanvasWithRects from './components/CanvasWithRects';
import InstructionList from './components/InstructionList';
import { Instruction, ImageWithInstructions } from './types';

const App: React.FC = () => {
  const [images, setImages] = useState<ImageWithInstructions[]>([]);
  const [activeImageId, setActiveImageId] = useState<string | null>(null);
  const [title, setTitle] = useState<string>('');

  const apiBase = import.meta.env.VITE_API_BASE;
  const appUrl = import.meta.env.VITE_APP_URL;

  const handleImageUpload = (file: File) => {
    const url = URL.createObjectURL(file);
    const newId = crypto.randomUUID();
    const newImage: ImageWithInstructions = {
      id: newId,
      imageUrl: url,
      imageFile: file,
      instructions: [],
      title: '',
    };
    setImages((prev) => [...prev, newImage]);
    setActiveImageId(newId);
  };

  const handleUpdateInstructions = (imageId: string, newInstructions: Instruction[]) => {
    setImages((prev) =>
      prev.map((img) =>
        img.id === imageId ? { ...img, instructions: newInstructions } : img
      )
    );
  };

  const handleEditImageTitle = (id: string) => {
    const current = images.find((img) => img.id === id);
    const newTitle = prompt('画像タイトルを入力してください', current?.title || '');
    if (newTitle !== null) {
      setImages((prev) =>
        prev.map((img) =>
          img.id === id ? { ...img, title: newTitle } : img
        )
      );
    }
  };

  const handleSaveAll = async () => {
    const formData = new FormData();
    images.forEach((img, index) => {
      formData.append(`image_${index}`, img.imageFile);
      formData.append(`instructions_${index}`, JSON.stringify(img.instructions));
    });

    formData.append('title', title);
    formData.append('json', JSON.stringify({
      title,
      items: images.map((img, index) => ({
        image: `image_${index}.png`,
        title: img.title,
        instructions: img.instructions,
      }))
    }));

    try {
      const res = await fetch(`${appUrl}/save.php`, {
        method: 'POST',
        body: formData,
      });
      const data = await res.json();

      if (data.success && data.id) {
        window.location.href = `${appUrl}/view.php?id=${data.id}`;
      } else {
        alert('保存に失敗しました');
      }
    } catch (e) {
      console.error(e);
      alert('保存中にエラーが発生しました');
    }
  };

  const activeImage = images.find((img) => img.id === activeImageId);

  return (
    <div className="min-h-screen bg-gray-50 text-gray-800 p-6">
      <h1 className="text-lg font-semibold mb-4 text-gray-700">修正指示ツール</h1>

      {/* 全体タイトル */}
      <div className="mb-4">
        <label className="block text-sm text-gray-600 mb-1">タイトル</label>
        <input
          type="text"
          value={title}
          onChange={(e) => setTitle(e.target.value)}
          className="w-full border max-w-md px-3 py-2 rounded text-sm"
          placeholder="案件名"
        />
      </div>

      {/* タブ */}
      <div className="flex space-x-2 mb-4">
        {images.map((img, index) => (
          <div key={img.id} className="relative">
            <button
              onClick={() => setActiveImageId(img.id)}
              className={`px-3 py-1 rounded-t ${
                img.id === activeImageId
                  ? 'bg-white border-b-0 border-gray-300 font-bold'
                  : 'bg-gray-200 text-gray-600'
              }`}
            >
              {img.title || `画像 ${index + 1}`}
            </button>
            画像 ${index + 1}
            <button
              onClick={() => handleEditImageTitle(img.id)}
              className="absolute right-0 top-0 text-xs px-1 text-blue-600 hover:text-blue-800"
              title="タイトルを編集"
            >
              ✏️
            </button>
          </div>
        ))}
        <button
          onClick={() => setActiveImageId(null)}
          className="px-3 py-1 bg-blue-500 text-white rounded hover:bg-blue-600"
        >
          ＋
        </button>
      </div>

      {/* コンテンツ */}
      {activeImageId === null ? (
        <ImageUploader onUpload={handleImageUpload} />
      ) : activeImage ? (
        <>
          <div className="flex gap-4">
            <div className="flex-1 bg-white rounded-lg p-4 shadow-sm">
              <CanvasWithRects
                imageUrl={activeImage.imageUrl}
                instructions={activeImage.instructions}
                setInstructions={(newInstructions) =>
                  handleUpdateInstructions(activeImage.id, newInstructions)
                }
              />
            </div>

            <div className="w-96 bg-white rounded-lg p-4 shadow-sm">
              <InstructionList
                instructions={
                  Array.isArray(activeImage.instructions)
                    ? activeImage.instructions
                    : [] // ← 万一関数になったとき空配列に
                }
                setInstructions={(newInstructions) =>
                handleUpdateInstructions(activeImage.id, newInstructions)
                }
              />
            </div>
          </div>

          <div className="mt-4">
            <button
              onClick={handleSaveAll}
              className="bg-blue-600 text-white px-4 py-2 rounded hover:bg-blue-700"
            >
              ✅ 完了
            </button>
          </div>
        </>
      ) : null}
    </div>
  );
};

export default App;
